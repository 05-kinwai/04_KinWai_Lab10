namespace UnityEditor.TestTools.TestRunner.CommandLineTest
{
    internal class RunData : ScriptableSingleton<RunData>
    {
        public bool isRunning;
        public ExecutionSettings executionSettings;
    }
}
